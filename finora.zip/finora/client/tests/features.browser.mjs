// Run against the isolated Vite fixture with VITE_API_BASE_URL=/test-api.
// PLAYWRIGHT_MODULE_PATH may point to an existing playwright/index.mjs.
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
import { mkdir } from "node:fs/promises";
const { chromium } = await import(
  process.env.PLAYWRIGHT_MODULE_PATH
    ? pathToFileURL(process.env.PLAYWRIGHT_MODULE_PATH).href
    : "playwright"
);
const browser = await chromium.launch({ channel: "chrome", headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
page.setDefaultTimeout(7000);
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
const now = new Date();
const month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
const date = `${month}-01`;
let transactions = [
  {
    id: 1,
    type: "income",
    category: "Salary",
    amount: 500,
    date,
    note: "Salary fixture",
  },
  {
    id: 2,
    type: "expense",
    category: "Food",
    amount: 80,
    date,
    note: "Food fixture",
  },
  {
    id: 3,
    type: "expense",
    category: "Transport",
    amount: 20,
    date,
    note: "Transport fixture",
  },
  {
    id: 4,
    type: "expense",
    category: "Entertainment",
    amount: 101,
    date,
    note: "Entertainment fixture",
  },
];
let budgets = [
  { id: 1, category: "Food", month, amount: 100 },
  { id: 2, category: "Transport", month, amount: 100 },
  { id: 3, category: "Entertainment", month, amount: 100 },
];
let nextTransaction = 5,
  nextBudget = 4,
  writes = 0,
  failNext = false;
await page.route("**/test-api/**", async (route) => {
  const request = route.request();
  const path = new URL(request.url()).pathname.replace("/test-api", "");
  const method = request.method();
  const input = request.postDataJSON();
  const reply = (data, status = 200) =>
    route.fulfill({
      status,
      contentType: "application/json",
      body: JSON.stringify({ data }),
    });
  if (method !== "GET") {
    writes++;
    // Exercise pending UI and Escape protection while the response is outstanding.
    await new Promise((resolve) => setTimeout(resolve, 120));
    if (failNext) {
      failNext = false;
      return route.fulfill({
        status: 400,
        contentType: "application/json",
        body: JSON.stringify({
          message: "Fixture server rejected this change. Try again.",
        }),
      });
    }
  }
  if (path === "/transactions" && method === "GET") return reply(transactions);
  if (path === "/budgets" && method === "GET") return reply(budgets);
  if (path === "/transactions" && method === "POST") {
    const item = { ...input, id: nextTransaction++ };
    transactions.push(item);
    return reply(item, 201);
  }
  if (path.startsWith("/transactions/") && method === "PUT") {
    const id = Number(path.split("/").at(-1));
    const item = { ...input, id };
    transactions = transactions.map((row) => (row.id === id ? item : row));
    return reply(item);
  }
  if (path.startsWith("/transactions/") && method === "DELETE") {
    const id = Number(path.split("/").at(-1));
    transactions = transactions.filter((row) => row.id !== id);
    return reply(id);
  }
  if (path === "/budgets" && method === "PUT") {
    const existing = budgets.find(
      (row) => row.category === input.category && row.month === input.month,
    );
    const item = { ...input, id: existing?.id ?? nextBudget++ };
    budgets = budgets.filter((row) => row.id !== item.id);
    budgets.push(item);
    return reply(item);
  }
  if (path.startsWith("/budgets/") && method === "DELETE") {
    const id = Number(path.split("/").at(-1));
    budgets = budgets.filter((row) => row.id !== id);
    return reply(id);
  }
  return route.fulfill({ status: 404, body: "{}" });
});

try {
  await page.goto(
    `${process.env.FEATURE_TEST_URL ?? "http://127.0.0.1:5178"}/tests/feature-fixture.html`,
  );
  await page.getByRole("table").waitFor();
  assert.equal(await page.locator("tbody tr").count(), 4);
  assert.match(
    await page.locator("tbody tr").first().textContent(),
    /Entertainment fixture/,
  );
  const add = page.getByRole("button", {
    name: "Add transaction",
    exact: true,
  });
  await add.click();
  const dialog = page.getByRole("dialog");
  await dialog.waitFor();
  const amount = dialog.getByLabel("Amount (USD)");
  assert.equal(
    await amount.evaluate((element) => element === document.activeElement),
    true,
  );
  for (let i = 0; i < 12; i++) {
    await page.keyboard.press("Tab");
    assert.equal(
      await dialog.evaluate((element) =>
        element.contains(document.activeElement),
      ),
      true,
    );
  }
  for (const invalid of ["", "0", "-1", "1.001", "abc"]) {
    await amount.fill(invalid);
    await dialog
      .getByRole("button", { name: "Add transaction", exact: true })
      .click();
    await dialog.getByRole("alert").waitFor();
    assert.equal(writes, 0);
  }
  await amount.fill("12.00");
  await dialog.getByLabel("Category", { exact: true }).selectOption("");
  await dialog
    .getByRole("button", { name: "Add transaction", exact: true })
    .click();
  await dialog.getByRole("alert").waitFor();
  assert.equal(writes, 0);
  await dialog.getByLabel("Category", { exact: true }).selectOption("Food");
  await amount.fill("0.30");
  await dialog.getByLabel("Date", { exact: true }).fill("9999-01-01");
  await dialog
    .getByRole("button", { name: "Add transaction", exact: true })
    .click();
  assert.equal(writes, 0);
  await dialog.getByLabel("Date", { exact: true }).fill(date);
  await dialog.getByRole("button", { name: "Income", exact: true }).click();
  await dialog.getByLabel("Note (optional)").fill("Browser income");
  failNext = true;
  await dialog
    .getByRole("button", { name: "Add transaction", exact: true })
    .click();
  await dialog
    .getByRole("alert")
    .filter({ hasText: "Fixture server rejected" })
    .waitFor();
  assert.equal(await amount.inputValue(), "0.30");
  assert.equal(transactions.length, 4);
  const retryCreate = dialog.getByRole("button", {
    name: "Add transaction",
    exact: true,
  });
  const writesBeforeRetry = writes;
  await retryCreate.click();
  await retryCreate.click({ force: true });
  await page.keyboard.press("Escape");
  assert.equal(await dialog.isVisible(), true);
  await dialog.waitFor({ state: "hidden" });
  assert.equal(transactions.length, 5);
  assert.equal(writes, writesBeforeRetry + 1);
  assert.equal(transactions.at(-1).amount, 0.3);
  assert.equal(
    await add.evaluate((element) => element === document.activeElement),
    true,
  );
  await page.getByRole("button", { name: /Edit Browser income/ }).click();
  await amount.fill("15.25");
  await dialog.getByRole("button", { name: "Expense", exact: true }).click();
  await dialog.getByLabel("Category", { exact: true }).selectOption("Food");
  await dialog.getByLabel("Date", { exact: true }).fill("2024-01-15");
  await dialog.getByLabel("Note (optional)").fill("Corrected browser expense");
  await dialog.getByRole("button", { name: "Save changes" }).click();
  await dialog.waitFor({ state: "hidden" });
  await page.reload();
  await page.getByRole("table").waitFor();
  assert.equal(await page.locator("tbody tr").count(), 5);
  assert.match(
    await page
      .locator("tbody tr")
      .filter({ hasText: "Corrected browser expense" })
      .textContent(),
    /Food.*2024-01-15.*\$15\.25/,
  );
  await page.getByLabel("Type", { exact: true }).selectOption("expense");
  await page.getByLabel("Category", { exact: true }).selectOption("Food");
  await page.getByLabel("Month", { exact: true }).fill("2024-01");
  assert.equal(await page.locator("tbody tr").count(), 1);
  assert.match(
    await page.locator(".transactions-summary").textContent(),
    /15.25/,
  );
  await page.getByLabel("Search", { exact: true }).fill("does not exist");
  await page.getByText("No transactions match", { exact: true }).waitFor();
  await page.getByRole("button", { name: "Clear filters" }).click();
  assert.equal(await page.locator("tbody tr").count(), 5);
  while (await page.getByRole("button", { name: /^Dismiss:/ }).count())
    await page
      .getByRole("button", { name: /^Dismiss:/ })
      .first()
      .click();
  const remove = page.getByRole("button", {
    name: /Delete Corrected browser expense/,
  });
  await remove.click();
  assert.equal(
    await dialog
      .getByRole("button", { name: "Keep transaction" })
      .evaluate((element) => element === document.activeElement),
    true,
  );
  await page.keyboard.press("Escape");
  await dialog.waitFor({ state: "hidden" });
  assert.equal(
    await remove.evaluate((element) => element === document.activeElement),
    true,
  );
  await remove.click();
  await dialog
    .getByRole("button", { name: "Delete transaction", exact: true })
    .click();
  await dialog.waitFor({ state: "hidden" });
  assert.equal(transactions.length, 4);
  assert.equal(
    await page
      .locator(".table-scroll")
      .evaluate((element) => element === document.activeElement),
    true,
  );
  await page.reload();
  await page.getByRole("table").waitFor();
  assert.equal(await page.locator("tbody tr").count(), 4);
  assert.equal(
    await page.getByText("Corrected browser expense", { exact: true }).count(),
    0,
  );

  await page
    .getByRole("button", { name: "Add transaction", exact: true })
    .click();
  await dialog.waitFor();
  await dialog.getByLabel("Amount (USD)").fill("12.50");
  await dialog.getByLabel("Category", { exact: true }).selectOption("Shopping");
  await dialog.getByLabel("Note (optional)").fill("Added browser expense");
  await dialog
    .getByRole("button", { name: "Add transaction", exact: true })
    .click();
  await dialog.waitFor({ state: "hidden" });
  assert.equal(transactions.length, 5);
  assert.match(
    await page
      .locator(".transactions-log tbody tr")
      .filter({ hasText: "Added browser expense" })
      .textContent(),
    /Shopping.*\$12\.50/,
  );
  await page
    .getByRole("button", { name: /Delete Added browser expense/ })
    .click();
  await dialog
    .getByRole("button", { name: "Delete transaction", exact: true })
    .click();
  await dialog.waitFor({ state: "hidden" });
  assert.equal(transactions.length, 4);

  await page.getByRole("button", { name: "Income test" }).click();
  assert.equal(
    await page.locator(".income-total .amount").textContent(),
    "$500.00",
  );
  await page.getByRole("button", { name: "Add income", exact: true }).click();
  await dialog.waitFor();
  await dialog.getByLabel("Amount (USD)").fill("80");
  await dialog
    .getByLabel("Category", { exact: true })
    .selectOption("Freelance");
  await dialog.getByLabel("Note (optional)").fill("Report sync income");
  failNext = true;
  await dialog.getByRole("button", { name: "Add income", exact: true }).click();
  await dialog
    .getByRole("alert")
    .filter({ hasText: "Fixture server rejected" })
    .waitFor();
  assert.equal(await dialog.getByLabel("Amount (USD)").inputValue(), "80");
  assert.equal(transactions.length, 4);
  await dialog.getByRole("button", { name: "Add income", exact: true }).click();
  await dialog.waitFor({ state: "hidden" });
  assert.equal(
    await page.locator(".income-total .amount").textContent(),
    "$580.00",
  );
  assert.match(
    await page
      .locator(".income-source")
      .filter({ hasText: "Salary" })
      .textContent(),
    /86\.2%/,
  );
  assert.match(
    await page
      .locator(".income-source")
      .filter({ hasText: "Freelance" })
      .textContent(),
    /13\.8%/,
  );
  assert.equal(await page.locator(".income-history tbody tr").count(), 2);
  await page.getByRole("button", { name: "Dashboard test" }).click();
  assert.deepEqual(
    await page.locator(".dashboard-stat-value").allTextContents(),
    ["$580.00", "$201.00", "$379.00"],
  );
  assert.match(
    await page.locator(".dashboard-stat-meta").textContent(),
    /65\.3%/,
  );
  assert.equal(
    await page.locator(".dashboard-balance").textContent(),
    "All-time balance$379.00",
  );
  assert.match(
    await page
      .locator(".dashboard-spending-row")
      .filter({ hasText: "Food" })
      .textContent(),
    /Near limit/,
  );
  assert.match(
    await page
      .locator(".dashboard-spending-row")
      .filter({ hasText: "Entertainment" })
      .textContent(),
    /Exceeded by \$1\.00/,
  );
  assert.equal(await page.locator(".dashboard-recent tbody tr").count(), 5);

  await page.getByRole("button", { name: "Income test" }).click();
  await page.getByRole("button", { name: /Edit Report sync income/ }).click();
  await dialog.getByLabel("Amount (USD)").fill("100");
  await dialog
    .getByLabel("Category", { exact: true })
    .selectOption("Other Income");
  await dialog.getByLabel("Date", { exact: true }).fill("2024-01-15");
  await dialog.getByRole("button", { name: "Save changes" }).click();
  await dialog.waitFor({ state: "hidden" });
  await page.reload();
  await page.getByRole("table").waitFor();
  await page.getByRole("button", { name: "Income test" }).click();
  assert.equal(
    await page.locator(".income-total .amount").textContent(),
    "$500.00",
  );
  await page.getByRole("button", { name: "Dashboard test" }).click();
  assert.deepEqual(
    await page.locator(".dashboard-stat-value").allTextContents(),
    ["$500.00", "$201.00", "$299.00"],
  );
  assert.match(
    await page.locator(".dashboard-stat-meta").textContent(),
    /59\.8%/,
  );
  assert.equal(
    await page.locator(".dashboard-balance").textContent(),
    "All-time balance$399.00",
  );
  await page.getByRole("button", { name: "Income test" }).click();
  await page.getByLabel("Month", { exact: true }).fill("2024-01");
  assert.equal(
    await page.locator(".income-total .amount").textContent(),
    "$100.00",
  );
  assert.match(
    await page
      .locator(".income-source")
      .filter({ hasText: "Other Income" })
      .textContent(),
    /100\.0%/,
  );
  assert.equal(await page.locator(".income-history tbody tr").count(), 1);

  await page.getByRole("button", { name: "Transactions test" }).click();
  await page.getByLabel("Type", { exact: true }).selectOption("income");
  await page
    .getByLabel("Category", { exact: true })
    .selectOption("Other Income");
  await page.getByLabel("Month", { exact: true }).fill("2024-01");
  assert.equal(await page.locator(".transactions-log tbody tr").count(), 1);
  assert.match(
    await page.locator(".transactions-summary").textContent(),
    /\$100\.00/,
  );

  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill("2024-01");
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$100\.00.*\$0\.00.*\$100\.00.*100\.0%/,
  );
  assert.match(
    await page.locator(".report-section").textContent(),
    /No spending this month/,
  );

  await page.getByRole("button", { name: "Income test" }).click();
  await page.getByLabel("Month", { exact: true }).fill("2024-01");
  await page.getByRole("button", { name: /Delete Report sync income/ }).click();
  await dialog
    .getByRole("button", { name: "Delete transaction", exact: true })
    .click();
  await dialog.waitFor({ state: "hidden" });
  assert.equal(
    await page.locator(".income-total .amount").textContent(),
    "$0.00",
  );
  assert.equal(await page.locator(".income-history tbody tr").count(), 0);
  await page.getByText("No income matches", { exact: true }).waitFor();

  await page.getByRole("button", { name: "Transactions test" }).click();
  await page.getByLabel("Type", { exact: true }).selectOption("income");
  await page
    .getByLabel("Category", { exact: true })
    .selectOption("Other Income");
  await page.getByLabel("Month", { exact: true }).fill("2024-01");
  assert.equal(await page.locator(".transactions-log tbody tr").count(), 0);
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill("2024-01");
  assert.match(
    await page.locator(".report-section").textContent(),
    /No transactions this month/,
  );
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$0\.00.*\$0\.00.*\$0\.00.*N\/A/,
  );

  await page.getByRole("button", { name: "Budgets test" }).click();
  assert.equal(await page.locator("tbody tr").count(), 7);
  const row = (category) =>
    page.locator("tbody tr").filter({
      has: page.getByRole("rowheader", { name: category, exact: true }),
    });
  assert.match(await row("Food").textContent(), /Near limit/);
  assert.match(await row("Transport").textContent(), /On track/);
  assert.match(await row("Entertainment").textContent(), /Exceeded by \$1.00/);
  await page.getByLabel("Budget month").fill("2030-04");
  await page
    .getByRole("button", { name: "Set Food budget", exact: true })
    .click();
  assert.equal(
    await dialog
      .getByLabel("Expense category")
      .locator("option")
      .evaluateAll((options) =>
        options.some((option) => option.value === "Salary"),
      ),
    false,
  );
  await dialog.getByLabel("Monthly limit (USD)").fill("0");
  const beforeInvalid = writes;
  await dialog.getByRole("button", { name: "Save budget" }).click();
  assert.equal(writes, beforeInvalid);
  await dialog.getByLabel("Monthly limit (USD)").fill("15.99");
  failNext = true;
  await dialog.getByRole("button", { name: "Save budget" }).click();
  await dialog
    .getByRole("alert")
    .filter({ hasText: "Fixture server rejected" })
    .waitFor();
  assert.equal(
    await dialog.getByLabel("Monthly limit (USD)").inputValue(),
    "15.99",
  );
  assert.equal(
    budgets.some(
      (item) => item.month === "2030-04" && item.category === "Food",
    ),
    false,
  );
  await dialog.getByRole("button", { name: "Save budget" }).click();
  await dialog.waitFor({ state: "hidden" });
  assert.match(await row("Food").textContent(), /15.99/);
  await page
    .getByRole("button", { name: "Edit Food budget", exact: true })
    .click();
  assert.equal(
    await dialog.getByLabel("Monthly limit (USD)").inputValue(),
    "15.99",
  );
  await dialog.getByLabel("Monthly limit (USD)").fill("20");
  await dialog.getByRole("button", { name: "Save budget" }).click();
  await dialog.waitFor({ state: "hidden" });
  assert.equal(
    budgets.filter(
      (item) => item.month === "2030-04" && item.category === "Food",
    ).length,
    1,
  );
  await page.reload();
  await page.getByRole("table").waitFor();
  await page.getByRole("button", { name: "Budgets test" }).click();
  await page.getByLabel("Budget month").fill("2030-04");
  assert.match(await row("Food").textContent(), /\$20\.00/);
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill("2030-04");
  assert.match(
    await page.locator("tbody tr").filter({ hasText: "Food" }).textContent(),
    /\$20\.00.*On track/,
  );
  await page.getByRole("button", { name: "Budgets test" }).click();
  await page.getByLabel("Budget month").fill("2030-04");
  await page
    .getByRole("button", { name: "Remove Food budget", exact: true })
    .click();
  await dialog
    .getByRole("button", { name: "Remove budget", exact: true })
    .click();
  await dialog.waitFor({ state: "hidden" });
  assert.match(await row("Food").textContent(), /No budget/);
  assert.equal(transactions.length, 4);
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill("2030-04");
  assert.match(
    await page.locator("tbody tr").filter({ hasText: "Food" }).textContent(),
    /No budget/,
  );
  await page.reload();
  await page.getByRole("table").waitFor();
  await page.getByRole("button", { name: "Budgets test" }).click();
  await page.getByLabel("Budget month").fill("2030-04");
  assert.match(await row("Food").textContent(), /No budget/);
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill("2030-04");
  assert.match(
    await page.locator("tbody tr").filter({ hasText: "Food" }).textContent(),
    /No budget/,
  );
  await page.getByRole("button", { name: "Budgets test" }).click();
  await page.getByRole("button", { name: "Read-only test" }).click();
  assert.equal(await page.locator("table button").count(), 0);

  for (const width of [360, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
      true,
      `overflow at ${width}`,
    );
  }
  await page.getByRole("button", { name: "Transactions test" }).click();
  for (const width of [360, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
      true,
      `transactions overflow at ${width}`,
    );
  }
  await page.setViewportSize({ width: 360, height: 560 });
  await page
    .getByRole("button", { name: "Add transaction", exact: true })
    .click();
  const rect = await dialog.boundingBox();
  assert.ok(
    rect &&
      rect.x >= 0 &&
      rect.y >= 0 &&
      rect.x + rect.width <= 361 &&
      rect.y + rect.height <= 561,
  );
  await mkdir("node_modules/.cache/feature-checks", { recursive: true });
  await page.screenshot({
    path: "node_modules/.cache/feature-checks/mobile-dialog.png",
  });
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: "Budgets test" }).click();
  await page.setViewportSize({ width: 360, height: 560 });
  const setHousing = page.getByRole("button", {
    name: "Set Housing budget",
    exact: true,
  });
  await setHousing.click();
  const budgetFormRect = await dialog.boundingBox();
  assert.ok(
    budgetFormRect &&
      budgetFormRect.x >= 0 &&
      budgetFormRect.y >= 0 &&
      budgetFormRect.x + budgetFormRect.width <= 361 &&
      budgetFormRect.y + budgetFormRect.height <= 561,
  );
  await page.screenshot({
    path: "node_modules/.cache/feature-checks/mobile-budget-form.png",
  });
  await page.keyboard.press("Escape");
  await dialog.waitFor({ state: "hidden" });
  assert.equal(
    await setHousing.evaluate((element) => element === document.activeElement),
    true,
  );
  const removeFood = page.getByRole("button", {
    name: "Remove Food budget",
    exact: true,
  });
  await removeFood.click();
  const removeDialogRect = await dialog.boundingBox();
  assert.ok(
    removeDialogRect &&
      removeDialogRect.x >= 0 &&
      removeDialogRect.y >= 0 &&
      removeDialogRect.x + removeDialogRect.width <= 361 &&
      removeDialogRect.y + removeDialogRect.height <= 561,
  );
  await page.keyboard.press("Escape");
  await dialog.waitFor({ state: "hidden" });
  assert.equal(
    await removeFood.evaluate((element) => element === document.activeElement),
    true,
  );
  for (const width of [360, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
      true,
      `budgets overflow at ${width}`,
    );
  }
  await page.screenshot({
    path: "node_modules/.cache/feature-checks/budgets.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Report test" }).click();
  assert.equal(await page.locator("tbody tr").count(), 7);
  assert.equal(await page.locator("table button").count(), 0);
  assert.equal(await page.locator(".report-category").count(), 7);
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$500.00.*\$201.00.*\$299.00.*59.8%/,
  );
  assert.match(
    await page.locator(".report-breakdown").textContent(),
    /Entertainment.*\$101.00.*50.2%/,
  );
  assert.match(
    await page.getByText(/Largest spending category/).textContent(),
    /Entertainment.*\$101.00.*50.2%/,
  );
  assert.match(
    await page
      .locator("tbody tr")
      .filter({ hasText: "Entertainment" })
      .textContent(),
    /101.0%.*Exceeded/,
  );
  assert.equal(
    await page
      .getByRole("progressbar", { name: "Entertainment budget used: 101.0%" })
      .getAttribute("value"),
    "100",
  );
  for (const width of [360, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
      true,
      `report overflow at ${width}`,
    );
  }
  await page.screenshot({
    path: "node_modules/.cache/feature-checks/report.png",
    fullPage: true,
  });
  await page.getByLabel("Report month").fill("2030-04");
  assert.match(
    await page.locator(".report-section").textContent(),
    /No transactions this month/,
  );
  assert.match(
    await page.locator(".report-summary").textContent(),
    /Savings rate: N\/A/,
  );
  assert.equal(await page.locator("progress").count(), 7);
  assert.equal(await page.locator('progress[value="0"]').count(), 7);
  await page.getByLabel("Report month").fill("");
  assert.equal(await page.getByLabel("Report month").inputValue(), "2030-04");

  await page.getByRole("button", { name: "Transactions test" }).click();
  await page.getByRole("button", { name: /Edit Food fixture/ }).click();
  await dialog.getByLabel("Amount (USD)").fill("130");
  await dialog.getByRole("button", { name: "Save changes" }).click();
  await dialog.waitFor({ state: "hidden" });
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill(month);
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$500\.00.*\$251\.00.*\$249\.00.*49\.8%/,
  );
  assert.match(
    await page.locator("tbody tr").filter({ hasText: "Food" }).textContent(),
    /130\.0%.*Exceeded by \$30\.00/,
  );
  assert.match(
    await page.locator(".report-breakdown").textContent(),
    /Entertainment.*\$101\.00.*40\.2%/,
  );

  await page.getByRole("button", { name: "Transactions test" }).click();
  await page.getByRole("button", { name: /Edit Food fixture/ }).click();
  await dialog.getByLabel("Category", { exact: true }).selectOption("Shopping");
  await dialog.getByRole("button", { name: "Save changes" }).click();
  await dialog.waitFor({ state: "hidden" });
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill(month);
  assert.match(
    await page.locator(".report-breakdown").textContent(),
    /Shopping.*\$130\.00.*51\.8%/,
  );
  assert.match(
    await page
      .locator("tbody tr")
      .filter({ hasText: "Shopping" })
      .textContent(),
    /No budget.*\$130\.00/,
  );

  await page.getByRole("button", { name: "Transactions test" }).click();
  await page.getByRole("button", { name: /Edit Food fixture/ }).click();
  await dialog.getByLabel("Date", { exact: true }).fill("2024-02-15");
  await dialog.getByRole("button", { name: "Save changes" }).click();
  await dialog.waitFor({ state: "hidden" });
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill(month);
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$500\.00.*\$121\.00.*\$379\.00.*75\.8%/,
  );
  await page.getByLabel("Report month").fill("2024-02");
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$0\.00.*\$130\.00.*-\$130\.00.*N\/A/,
  );
  assert.match(
    await page.locator(".report-section").textContent(),
    /Overspent/,
  );
  assert.match(
    await page.locator(".report-breakdown").textContent(),
    /Shopping.*\$130\.00.*100\.0%/,
  );

  await page.getByRole("button", { name: "Transactions test" }).click();
  await page.getByRole("button", { name: /Delete Food fixture/ }).click();
  await dialog
    .getByRole("button", { name: "Delete transaction", exact: true })
    .click();
  await dialog.waitFor({ state: "hidden" });
  await page.getByRole("button", { name: "Report test" }).click();
  await page.getByLabel("Report month").fill("2024-02");
  assert.match(
    await page.locator(".report-section").textContent(),
    /No transactions this month/,
  );
  assert.match(
    await page.locator(".report-summary").textContent(),
    /\$0\.00.*\$0\.00.*\$0\.00.*N\/A/,
  );

  const appOrigin = new URL(
    process.env.FEATURE_TEST_URL ?? "http://127.0.0.1:5178",
  ).origin;
  const shellRoutes = [
    {
      path: "/",
      heading: "Dashboard",
      ready: '.dashboard-section[aria-busy="false"]',
    },
    {
      path: "/income",
      heading: "Income",
      ready: '.income-history[aria-busy="false"]',
    },
    {
      path: "/transactions",
      heading: "Transactions",
      ready: '.transactions-log[aria-busy="false"]',
    },
    { path: "/transactions/new", heading: "Add transaction" },
    {
      path: "/budgets",
      heading: "Budgets",
      ready: '.budgets-section [aria-busy="false"]',
    },
    {
      path: "/reports/monthly",
      heading: "Monthly report",
      ready: '.report-section[aria-busy="false"]',
    },
    { path: "/about", heading: "About us" },
    { path: "/missing-route", heading: "We couldn’t find that page." },
  ];
  const shellViewports = [
    { width: 360, height: 800, label: "360px" },
    { width: 390, height: 844, label: "390px" },
    { width: 768, height: 900, label: "768px" },
    { width: 1024, height: 900, label: "1024px" },
    { width: 1440, height: 1000, label: "1440px" },
    { width: 667, height: 375, label: "short landscape" },
    { width: 720, height: 500, label: "200% zoom-equivalent CSS viewport" },
  ];
  for (const viewport of shellViewports) {
    await page.setViewportSize(viewport);
    for (const route of shellRoutes) {
      await page.goto(`${appOrigin}${route.path}`);
      await page
        .getByRole("heading", { name: route.heading, exact: true })
        .waitFor();
      if (route.ready) await page.locator(route.ready).waitFor();
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth + 1,
        ),
        true,
        `${route.path} overflows at ${viewport.label}`,
      );
    }
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${appOrigin}/`);
  await page.locator('.dashboard-section[aria-busy="false"]').waitFor();
  const openNavigation = page.getByRole("button", {
    name: "Open navigation",
    exact: true,
  });
  await openNavigation.click();
  const drawer = page.getByRole("dialog", { name: "Main navigation" });
  await drawer.waitFor();
  const drawerClose = drawer.getByRole("button", {
    name: "Close navigation",
    exact: true,
  });
  assert.equal(
    await drawerClose.evaluate((element) => element === document.activeElement),
    true,
  );
  await page.keyboard.press("Shift+Tab");
  const aboutLink = drawer.getByRole("link", { name: "About us", exact: true });
  assert.equal(
    await aboutLink.evaluate((element) => element === document.activeElement),
    true,
  );
  await page.keyboard.press("Tab");
  assert.equal(
    await drawerClose.evaluate((element) => element === document.activeElement),
    true,
  );
  await page.keyboard.press("Tab");
  await page.keyboard.press("Tab");
  await page.keyboard.press("Tab");
  await page.keyboard.press("Enter");
  await page
    .getByRole("heading", { name: "Transactions", exact: true })
    .waitFor();
  await page.waitForFunction(
    () =>
      !document
        .querySelector("#app-sidebar")
        ?.classList.contains("app-sidebar--open"),
  );
  assert.equal(
    await page
      .locator("#main-content")
      .evaluate((element) => element === document.activeElement),
    true,
  );
  assert.equal(
    await page
      .locator("#main-content")
      .evaluate((element) => getComputedStyle(element).outlineStyle),
    "solid",
  );
  await page.setViewportSize({ width: 390, height: 844 });
  await openNavigation.click();
  await drawer.waitFor();
  await page.setViewportSize({ width: 768, height: 900 });
  await page.waitForFunction(
    () =>
      !document
        .querySelector("#app-sidebar")
        ?.classList.contains("app-sidebar--open"),
  );
  assert.equal(await openNavigation.getAttribute("aria-expanded"), "false");
  await page.setViewportSize({ width: 360, height: 800 });
  await page.goto(`${appOrigin}/missing-route`);
  await page
    .getByRole("heading", { name: "We couldn’t find that page.", exact: true })
    .waitFor();
  await page.screenshot({
    path: "node_modules/.cache/feature-checks/not-found-mobile.png",
    fullPage: true,
  });
  await page.getByRole("link", { name: "Back to dashboard" }).click();
  await page.getByRole("heading", { name: "Dashboard", exact: true }).waitFor();
  assert.deepEqual(errors, []);
  console.log(
    "PASS: report totals, percentages, all categories, capped bars with actual usage text, empty month, required month, read-only comparison, and responsive widths.",
  );
  assert.deepEqual(errors, []);
  console.log(
    "PASS: fixture-backed create/edit/delete, combined filters, validation, failed-request draft retention, pending Escape guard, dialog focus/Tab/Escape/restoration, budget set/edit/remove, 7 category rows, statuses, read-only mode, no horizontal overflow at 360/390/768/1024/1440px. This is not a live NestJS verification.",
  );
} finally {
  await browser.close();
}
